# micro-root
This is the root html file for the micro frontend application
