import { Component } from '@angular/core';

@Component({
  selector: 'navbar-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
