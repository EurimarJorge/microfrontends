import { Component } from '@angular/core';

@Component({
  selector: 'main-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'navbar';
}
